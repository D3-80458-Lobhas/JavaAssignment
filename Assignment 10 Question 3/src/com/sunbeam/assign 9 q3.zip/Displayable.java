package com.sunbeam;

interface Displayable {
	void display();
	Object get();
}
